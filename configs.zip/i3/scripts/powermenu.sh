#!/bin/bash

chosen=$(printf "Выключить\nПерезагрузить\nСон\nГибернация\nЗаблокировать\nВыйти из i3" | rofi -dmenu -i -p "Система" -theme-str '
window { width: 280px; background-color: #0d1526; border: 2px; border-color: #51a2da; }
listview { lines: 6; background-color: #0d1526; }
element { padding: 8px; background-color: #0d1526; text-color: #eceff4; }
element selected { background-color: #3c6eb4; text-color: #ffffff; }
inputbar { children: [prompt]; background-color: #0d1526; }
prompt { text-color: #51a2da; padding: 8px; }
')

case "$chosen" in
    "Выключить") systemctl poweroff ;;
    "Перезагрузить") systemctl reboot ;;
    "Сон") systemctl suspend ;;
    "Гибернация") systemctl hibernate ;;
    "Заблокировать") i3lock -c 0d1526 ;;
    "Выйти из i3") i3-msg exit ;;
esac
